# for minted package
$pdflatex='pdflatex -shell-escape';

